package com.example.ui.screens

import android.annotation.SuppressLint
import android.net.Uri
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Cancel
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Replay
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.example.model.FileTransferStatus
import com.example.model.TransferFileItem
import com.example.network.PeerJsWebPortalHtml
import com.example.ui.components.CopyrightFooter
import com.example.ui.components.categoryIcon
import com.example.ui.components.formatBytesArabic
import com.example.ui.components.formatSpeedArabic
import com.example.ui.theme.CoralRose
import com.example.ui.theme.ElectricCyan
import com.example.ui.theme.GlassBorder
import com.example.ui.theme.HotspotAmber
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.MidnightCard
import com.example.ui.theme.MidnightSurface
import com.example.ui.theme.NeonEmerald
import com.example.ui.theme.TextSecondary
import com.example.viewmodel.P2PUiState

@Composable
fun LiveTransferScreen(
    uiState: P2PUiState,
    onBack: () -> Unit,
    onTogglePauseResume: () -> Unit,
    onCancelTransfer: () -> Unit,
    onRestartTransfer: () -> Unit,
    onApproveReceiver: () -> Unit = {},
    onRejectReceiver: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    BackHandler(onBack = onBack)

    val animatedOverallProgress by animateFloatAsState(
        targetValue = uiState.overallProgressFraction,
        animationSpec = tween(250),
        label = "overall_progress"
    )

    Column(modifier = modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 12.dp)
        ) {
            ScreenTopBar(
                title = "النقل الحي • برق sher",
                subtitle = uiState.connectedPeerLabel,
                accentColor = ElectricCyan,
                onBack = onBack
            )

            Spacer(modifier = Modifier.height(14.dp))

            // Live Speedometer & Overall Chunking Telemetry Hero Card
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(22.dp))
                    .background(
                        Brush.linearGradient(
                            listOf(
                                Color(0xFF092235),
                                MidnightSurface,
                                Color(0xFF08241C)
                            )
                        )
                    )
                    .border(
                        width = 1.4.dp,
                        brush = Brush.horizontalGradient(listOf(ElectricCyan, NeonEmerald)),
                        shape = RoundedCornerShape(22.dp)
                    )
                    .padding(18.dp)
                    .testTag("live_speed_telemetry_card")
            ) {
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = uiState.transferDirection.arabicTitle,
                                style = MaterialTheme.typography.labelLarge,
                                color = NeonEmerald
                            )
                            Row(verticalAlignment = Alignment.Bottom) {
                                Icon(
                                    imageVector = Icons.Filled.Speed,
                                    contentDescription = null,
                                    tint = ElectricCyan,
                                    modifier = Modifier
                                        .size(28.dp)
                                        .padding(bottom = 4.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = formatSpeedArabic(uiState.liveOverallSpeedBytesPerSec),
                                    fontFamily = JetBrainsMonoFontFamily,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 28.sp,
                                    color = ElectricCyan,
                                    modifier = Modifier.testTag("live_mbps_speed_text")
                                )
                            }
                            Text(
                                text = "أعلى سرعة: ${formatSpeedArabic(uiState.peakSpeedBytesPerSec)} • الكود: ${uiState.connectionCode}",
                                style = MaterialTheme.typography.labelMedium,
                                color = TextSecondary
                            )
                        }

                        Box(
                            contentAlignment = Alignment.Center,
                            modifier = Modifier
                                .size(68.dp)
                                .clip(CircleShape)
                                .background(Color(0xFF07101E))
                                .border(2.dp, NeonEmerald, CircleShape)
                        ) {
                            Text(
                                text = "${(animatedOverallProgress * 100).toInt()}%",
                                fontFamily = JetBrainsMonoFontFamily,
                                fontWeight = FontWeight.Bold,
                                fontSize = 18.sp,
                                color = Color.White
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    LinearProgressIndicator(
                        progress = { animatedOverallProgress },
                        color = ElectricCyan,
                        trackColor = Color(0xFF070E1A),
                        strokeCap = StrokeCap.Round,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(10.dp)
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "المنقول: ${formatBytesArabic(uiState.transferredBytes)} / ${formatBytesArabic(uiState.totalBytes)}",
                            fontFamily = JetBrainsMonoFontFamily,
                            fontSize = 12.sp,
                            color = Color.White
                        )
                        Text(
                            text = "الوقت المتبقي: ${uiState.formattedEtaLabel}",
                            fontFamily = JetBrainsMonoFontFamily,
                            fontSize = 12.sp,
                            color = NeonEmerald,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.testTag("live_eta_text")
                        )
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "الجلسة: ${uiState.sessionId}",
                            fontFamily = JetBrainsMonoFontFamily,
                            fontSize = 11.sp,
                            color = TextSecondary
                        )
                        Text(
                            text = "الدفعات (Chunks): ${uiState.completedChunksCount} / ${uiState.totalChunksCount}",
                            fontFamily = JetBrainsMonoFontFamily,
                            fontSize = 11.sp,
                            color = HotspotAmber
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Transfer Controls Row: Pause/Resume, Cancel, and Restart/Resume Failed
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = onTogglePauseResume,
                    enabled = uiState.isTransferRunning,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (uiState.isPaused) NeonEmerald else HotspotAmber
                    ),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                        .testTag("pause_resume_transfer_button")
                ) {
                    Icon(
                        imageVector = if (uiState.isPaused) Icons.Filled.PlayArrow else Icons.Filled.Pause,
                        contentDescription = null,
                        tint = Color(0xFF1A1000),
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = if (uiState.isPaused) "استئناف" else "إيقاف مؤقت",
                        style = MaterialTheme.typography.labelLarge,
                        color = Color(0xFF1A1000)
                    )
                }

                OutlinedButton(
                    onClick = onCancelTransfer,
                    enabled = uiState.isTransferRunning,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                        .testTag("cancel_transfer_button")
                ) {
                    Icon(
                        imageVector = Icons.Filled.Cancel,
                        contentDescription = null,
                        tint = CoralRose,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "إلغاء النقل",
                        style = MaterialTheme.typography.labelLarge,
                        color = CoralRose
                    )
                }

                OutlinedButton(
                    onClick = onRestartTransfer,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                        .testTag("restart_transfer_button")
                ) {
                    Icon(
                        imageVector = Icons.Filled.Replay,
                        contentDescription = null,
                        tint = ElectricCyan,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "إعادة / إكمال",
                        style = MaterialTheme.typography.labelLarge,
                        color = Color.White
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Unified Folder Transfer Summary Banner when transferring whole folder(s)
            if (uiState.activeFolderNames.isNotEmpty()) {
                val completedFilesCount = uiState.files.count { it.status == FileTransferStatus.COMPLETED }
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .background(Color(0xFF211709))
                        .border(1.dp, HotspotAmber.copy(alpha = 0.7f), RoundedCornerShape(16.dp))
                        .padding(12.dp)
                        .testTag("live_folder_summary_card")
                ) {
                    Column {
                        Text(
                            text = "📁 نقل مجلد موحّد: ${uiState.activeFolderNames.joinToString(" ، ")}",
                            style = MaterialTheme.typography.titleMedium,
                            color = HotspotAmber,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "العناصر المكتملة: $completedFilesCount / ${uiState.files.size} • الحجم الكلي: ${formatBytesArabic(uiState.totalBytes)} • مع إعادة بناء المجلدات الفرعية",
                            style = MaterialTheme.typography.labelMedium,
                            color = Color(0xFFFDE68A)
                        )
                    }
                }
                Spacer(modifier = Modifier.height(10.dp))
            }

            Text(
                text = "حالة كل ملف والتحقق من البصمة الرقمية (SHA-256):",
                style = MaterialTheme.typography.titleMedium,
                color = Color.White
            )

            Spacer(modifier = Modifier.height(8.dp))

            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .testTag("live_files_lazy_column")
            ) {
                items(uiState.files.distinctBy { it.id }, key = { it.id }) { fileItem ->
                    LiveFileProgressCard(
                        item = fileItem,
                        chunkSizeLabel = uiState.selectedChunkSize.label
                    )
                }
            }
        }

        CopyrightFooter()
    }

    uiState.incomingConnectionRequest?.let { req ->
        IncomingConnectionRequestDialog(
            request = req,
            onApprove = onApproveReceiver,
            onReject = onRejectReceiver
        )
    }
}

@Composable
private fun LiveFileProgressCard(
    item: TransferFileItem,
    chunkSizeLabel: String
) {
    val badgeColor = Color(item.category.badgeColorHex)
    val animatedFileProgress by animateFloatAsState(
        targetValue = item.progressFraction,
        animationSpec = tween(180),
        label = "file_progress_${item.id}"
    )
    val isDone = item.status == FileTransferStatus.COMPLETED
    val isFailed = item.status == FileTransferStatus.FAILED || item.status == FileTransferStatus.CANCELLED

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .background(MidnightCard)
            .border(
                width = 1.dp,
                color = when {
                    isDone -> NeonEmerald.copy(alpha = 0.65f)
                    isFailed -> CoralRose.copy(alpha = 0.65f)
                    else -> GlassBorder
                },
                shape = RoundedCornerShape(18.dp)
            )
            .padding(14.dp)
            .testTag("live_file_card_${item.id}")
    ) {
        Column {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    Box(
                        contentAlignment = Alignment.Center,
                        modifier = Modifier
                            .size(42.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(badgeColor.copy(alpha = 0.18f))
                    ) {
                        Icon(
                            imageVector = when {
                                isDone -> Icons.Filled.CheckCircle
                                isFailed -> Icons.Filled.ErrorOutline
                                else -> categoryIcon(item.category)
                            },
                            contentDescription = item.category.arabicLabel,
                            tint = when {
                                isDone -> NeonEmerald
                                isFailed -> CoralRose
                                else -> badgeColor
                            },
                            modifier = Modifier.size(24.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = item.displayPathOrName,
                            style = MaterialTheme.typography.titleMedium,
                            color = Color.White,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = if (item.isDirectory) {
                                "مجلد فرعي فارغ • ${item.status.arabicLabel}"
                            } else {
                                "${item.category.arabicLabel} • ${item.status.arabicLabel}"
                            },
                            style = MaterialTheme.typography.labelMedium,
                            color = when {
                                isDone -> NeonEmerald
                                isFailed -> CoralRose
                                else -> TextSecondary
                            }
                        )
                    }
                }

                Surface(
                    color = when {
                        isDone -> NeonEmerald.copy(alpha = 0.18f)
                        isFailed -> CoralRose.copy(alpha = 0.18f)
                        else -> ElectricCyan.copy(alpha = 0.16f)
                    },
                    shape = RoundedCornerShape(999.dp)
                ) {
                    Text(
                        text = when {
                            isDone -> "اكتمل 100%"
                            isFailed -> item.status.arabicLabel
                            else -> formatSpeedArabic(item.currentSpeedBytesPerSec)
                        },
                        fontFamily = JetBrainsMonoFontFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp,
                        color = when {
                            isDone -> NeonEmerald
                            isFailed -> CoralRose
                            else -> ElectricCyan
                        },
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            LinearProgressIndicator(
                progress = { animatedFileProgress },
                color = when {
                    isDone -> NeonEmerald
                    isFailed -> CoralRose
                    else -> ElectricCyan
                },
                trackColor = Color(0xFF070D19),
                strokeCap = StrokeCap.Round,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(8.dp)
            )

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "الحجم: ${formatBytesArabic(item.transferredBytes)} / ${formatBytesArabic(item.sizeBytes)}",
                    fontFamily = JetBrainsMonoFontFamily,
                    fontSize = 11.sp,
                    color = Color(0xFFCBD5E1)
                )
                Text(
                    text = "الدفعات: ${item.completedChunks} / ${item.totalChunks} ($chunkSizeLabel)",
                    fontFamily = JetBrainsMonoFontFamily,
                    fontSize = 11.sp,
                    color = HotspotAmber
                )
            }

            // SHA-256 Verification Badge
            if (item.sha256Verified || item.sha256Expected.isNotEmpty()) {
                Spacer(modifier = Modifier.height(6.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Filled.VerifiedUser,
                        contentDescription = null,
                        tint = if (item.sha256Verified) NeonEmerald else ElectricCyan,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    val hashPreview = (item.sha256Actual.ifBlank { item.sha256Expected }).take(16)
                    Text(
                        text = if (item.sha256Verified) {
                            "تم التحقق من سلامة الملف (SHA-256: $hashPreview...)"
                        } else {
                            "بصمة SHA-256 للملف: $hashPreview..."
                        },
                        fontFamily = JetBrainsMonoFontFamily,
                        fontSize = 10.sp,
                        color = if (item.sha256Verified) NeonEmerald else TextSecondary
                    )
                }
            }

            item.errorMessage?.let { err ->
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = err,
                    style = MaterialTheme.typography.labelMedium,
                    color = CoralRose
                )
            }
        }
    }
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun WebRtcPeerJsPortalScreen(
    uiState: P2PUiState,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    BackHandler(onBack = onBack)

    var filePathCallback by remember { mutableStateOf<ValueCallback<Array<Uri>>?>(null) }
    val webFilePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenMultipleDocuments()
    ) { uris ->
        filePathCallback?.onReceiveValue(uris.toTypedArray())
        filePathCallback = null
    }

    Column(modifier = modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 10.dp)
        ) {
            ScreenTopBar(
                title = "بوابة الويب • برق sher",
                subtitle = "تعمل داخل التطبيق وعبر الرابط ${uiState.networkStatus.webPortalUrl}",
                accentColor = NeonEmerald,
                onBack = onBack
            )

            Spacer(modifier = Modifier.height(10.dp))

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .clip(RoundedCornerShape(20.dp))
                    .border(1.dp, GlassBorder, RoundedCornerShape(20.dp))
            ) {
                val htmlContent = remember(uiState.connectionCode, uiState.networkStatus.localIp) {
                    PeerJsWebPortalHtml.buildHtml(
                        defaultCode = uiState.connectionCode,
                        hostIp = uiState.networkStatus.localIp,
                        hostPort = uiState.networkStatus.port
                    )
                }

                AndroidView(
                    factory = { ctx ->
                        WebView(ctx).apply {
                            settings.javaScriptEnabled = true
                            settings.domStorageEnabled = true
                            settings.allowFileAccess = true
                            settings.allowContentAccess = true
                            settings.mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
                            webViewClient = WebViewClient()
                            webChromeClient = object : WebChromeClient() {
                                override fun onShowFileChooser(
                                    webView: WebView?,
                                    callback: ValueCallback<Array<Uri>>?,
                                    fileChooserParams: FileChooserParams?
                                ): Boolean {
                                    filePathCallback?.onReceiveValue(null)
                                    filePathCallback = callback
                                    webFilePickerLauncher.launch(arrayOf("*/*"))
                                    return true
                                }
                            }
                            loadDataWithBaseURL(
                                uiState.networkStatus.webPortalUrl,
                                htmlContent,
                                "text/html",
                                "UTF-8",
                                null
                            )
                        }
                    },
                    modifier = Modifier.fillMaxSize()
                )
            }
        }

        CopyrightFooter()
    }
}
