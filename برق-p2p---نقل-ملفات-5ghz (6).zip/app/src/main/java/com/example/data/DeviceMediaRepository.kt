package com.example.data

import android.content.ContentResolver
import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.graphics.BitmapFactory
import android.media.ThumbnailUtils
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.DocumentsContract
import android.provider.MediaStore
import android.util.Size
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import com.example.model.DeviceMediaItem
import com.example.model.FileCategory
import com.example.model.FolderBatchInfo
import com.example.model.PersistedSafFolderItem
import com.example.model.StorageFolderItem
import com.example.model.TransferFileItem
import com.example.util.Sha256Util
import java.io.File
import java.net.URLDecoder
import java.util.Locale
import java.util.UUID
import kotlin.math.max

/**
 * Queries real device media and files via MediaStore, accessible storage directories,
 * and Storage Access Framework (SAF) DocumentTrees.
 */
object DeviceMediaRepository {

    fun loadImages(context: Context, maxItems: Int = 250): List<DeviceMediaItem> {
        val resolver = context.contentResolver
        val items = mutableListOf<DeviceMediaItem>()
        val projection = arrayOf(
            MediaStore.Images.Media._ID,
            MediaStore.Images.Media.DISPLAY_NAME,
            MediaStore.Images.Media.SIZE,
            MediaStore.Images.Media.DATE_MODIFIED,
            MediaStore.Images.Media.MIME_TYPE,
            MediaStore.Images.Media.BUCKET_DISPLAY_NAME
        )
        val sortOrder = "${MediaStore.Images.Media.DATE_MODIFIED} DESC"
        try {
            resolver.query(
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                projection,
                null,
                null,
                sortOrder
            )?.use { cursor ->
                val idCol = cursor.getColumnIndexOrThrow(MediaStore.Images.Media._ID)
                val nameCol = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DISPLAY_NAME)
                val sizeCol = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.SIZE)
                val dateCol = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATE_MODIFIED)
                val mimeCol = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.MIME_TYPE)
                val bucketCol = cursor.getColumnIndex(MediaStore.Images.Media.BUCKET_DISPLAY_NAME)

                var count = 0
                while (cursor.moveToNext() && count < maxItems) {
                    val id = cursor.getLong(idCol)
                    val name = cursor.getString(nameCol) ?: "IMG_$id.jpg"
                    val size = cursor.getLong(sizeCol)
                    if (size <= 0L) continue
                    val dateSec = cursor.getLong(dateCol)
                    val mime = cursor.getString(mimeCol)
                    val bucket = if (bucketCol >= 0) cursor.getString(bucketCol) ?: "" else ""
                    val contentUri = ContentUris.withAppendedId(
                        MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                        id
                    )
                    val thumb = if (count < 24) loadMediaThumbnail(resolver, contentUri, id, isVideo = false) else null
                    items.add(
                        DeviceMediaItem(
                            id = "img_$id",
                            name = name,
                            uri = contentUri,
                            sizeBytes = size,
                            dateModifiedMillis = dateSec * 1000L,
                            mimeType = mime,
                            bucketOrFolderName = bucket,
                            category = FileCategory.IMAGE,
                            thumbnailBitmap = thumb
                        )
                    )
                    count++
                }
            }
        } catch (_: Exception) {
        }
        return items
    }

    fun loadVideos(context: Context, maxItems: Int = 200): List<DeviceMediaItem> {
        val resolver = context.contentResolver
        val items = mutableListOf<DeviceMediaItem>()
        val projection = arrayOf(
            MediaStore.Video.Media._ID,
            MediaStore.Video.Media.DISPLAY_NAME,
            MediaStore.Video.Media.SIZE,
            MediaStore.Video.Media.DATE_MODIFIED,
            MediaStore.Video.Media.DURATION,
            MediaStore.Video.Media.MIME_TYPE,
            MediaStore.Video.Media.BUCKET_DISPLAY_NAME
        )
        val sortOrder = "${MediaStore.Video.Media.DATE_MODIFIED} DESC"
        try {
            resolver.query(
                MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
                projection,
                null,
                null,
                sortOrder
            )?.use { cursor ->
                val idCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media._ID)
                val nameCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DISPLAY_NAME)
                val sizeCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.SIZE)
                val dateCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DATE_MODIFIED)
                val durCol = cursor.getColumnIndex(MediaStore.Video.Media.DURATION)
                val mimeCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.MIME_TYPE)
                val bucketCol = cursor.getColumnIndex(MediaStore.Video.Media.BUCKET_DISPLAY_NAME)

                var count = 0
                while (cursor.moveToNext() && count < maxItems) {
                    val id = cursor.getLong(idCol)
                    val name = cursor.getString(nameCol) ?: "VID_$id.mp4"
                    val size = cursor.getLong(sizeCol)
                    if (size <= 0L) continue
                    val dateSec = cursor.getLong(dateCol)
                    val duration = if (durCol >= 0) cursor.getLong(durCol) else 0L
                    val mime = cursor.getString(mimeCol)
                    val bucket = if (bucketCol >= 0) cursor.getString(bucketCol) ?: "" else ""
                    val contentUri = ContentUris.withAppendedId(
                        MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
                        id
                    )
                    val thumb = if (count < 16) loadMediaThumbnail(resolver, contentUri, id, isVideo = true) else null
                    items.add(
                        DeviceMediaItem(
                            id = "vid_$id",
                            name = name,
                            uri = contentUri,
                            sizeBytes = size,
                            dateModifiedMillis = dateSec * 1000L,
                            durationMillis = duration,
                            mimeType = mime,
                            bucketOrFolderName = bucket,
                            category = FileCategory.VIDEO,
                            thumbnailBitmap = thumb
                        )
                    )
                    count++
                }
            }
        } catch (_: Exception) {
        }
        return items
    }

    fun loadAudioFiles(context: Context, maxItems: Int = 250): List<DeviceMediaItem> {
        val resolver = context.contentResolver
        val items = mutableListOf<DeviceMediaItem>()
        val projection = arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.DISPLAY_NAME,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.SIZE,
            MediaStore.Audio.Media.DATE_MODIFIED,
            MediaStore.Audio.Media.DURATION,
            MediaStore.Audio.Media.MIME_TYPE,
            MediaStore.Audio.Media.ARTIST
        )
        val sortOrder = "${MediaStore.Audio.Media.DATE_MODIFIED} DESC"
        try {
            resolver.query(
                MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
                projection,
                null,
                null,
                sortOrder
            )?.use { cursor ->
                val idCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
                val nameCol = cursor.getColumnIndex(MediaStore.Audio.Media.DISPLAY_NAME)
                val titleCol = cursor.getColumnIndex(MediaStore.Audio.Media.TITLE)
                val sizeCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.SIZE)
                val dateCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DATE_MODIFIED)
                val durCol = cursor.getColumnIndex(MediaStore.Audio.Media.DURATION)
                val mimeCol = cursor.getColumnIndex(MediaStore.Audio.Media.MIME_TYPE)
                val artistCol = cursor.getColumnIndex(MediaStore.Audio.Media.ARTIST)

                var count = 0
                while (cursor.moveToNext() && count < maxItems) {
                    val id = cursor.getLong(idCol)
                    val displayName = (if (nameCol >= 0) cursor.getString(nameCol) else null)
                        ?: (if (titleCol >= 0) cursor.getString(titleCol) else null)
                        ?: "Audio_$id.mp3"
                    val size = cursor.getLong(sizeCol)
                    if (size <= 0L) continue
                    val dateSec = cursor.getLong(dateCol)
                    val duration = if (durCol >= 0) cursor.getLong(durCol) else 0L
                    val mime = if (mimeCol >= 0) cursor.getString(mimeCol) else "audio/mpeg"
                    val artist = if (artistCol >= 0) cursor.getString(artistCol) ?: "" else ""
                    val contentUri = ContentUris.withAppendedId(
                        MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
                        id
                    )
                    items.add(
                        DeviceMediaItem(
                            id = "aud_$id",
                            name = displayName,
                            uri = contentUri,
                            sizeBytes = size,
                            dateModifiedMillis = dateSec * 1000L,
                            durationMillis = duration,
                            mimeType = mime,
                            bucketOrFolderName = artist,
                            category = FileCategory.AUDIO
                        )
                    )
                    count++
                }
            }
        } catch (_: Exception) {
        }
        return items
    }

    /**
     * Loads general files (Documents, PDFs, ZIP/RAR Archives, APKs, Downloads, Recent files)
     * from MediaStore.Files, MediaStore.Downloads (API 29+), and accessible storage directories.
     */
    private data class RecursiveDirStats(
        val fileCount: Int,
        val subfolderCount: Int,
        val emptySubfolderCount: Int,
        val totalBytes: Long
    )

    fun loadGeneralFilesAndFolders(
        context: Context
    ): Pair<List<DeviceMediaItem>, List<StorageFolderItem>> {
        val resolver = context.contentResolver
        val seenKeys = HashSet<String>()
        val allFiles = mutableListOf<DeviceMediaItem>()
        val mediaStoreFolderGroups = LinkedHashMap<String, MutableList<DeviceMediaItem>>()

        @Suppress("DEPRECATION")
        val externalRootPath = try {
            Environment.getExternalStorageDirectory()?.absolutePath?.trimEnd('/') ?: "/storage/emulated/0"
        } catch (_: Exception) {
            "/storage/emulated/0"
        }

        fun recordMediaStoreFolderItem(relDirRaw: String, item: DeviceMediaItem) {
            val cleanRel = relDirRaw.trim().trim('/').replace('\\', '/')
            if (cleanRel.isBlank() || cleanRel.lowercase(Locale.ROOT).startsWith("android/")) return
            val segments = cleanRel.split('/').filter { it.isNotBlank() }
            if (segments.isEmpty()) return
            // Register both the immediate subfolder under a root (e.g. "Download/ropon") and the exact folder path
            if (segments.size >= 2) {
                val topSubfolder = "${segments[0]}/${segments[1]}"
                mediaStoreFolderGroups.getOrPut(topSubfolder) { mutableListOf() }.add(item)
            }
            mediaStoreFolderGroups.getOrPut(cleanRel) { mutableListOf() }.add(item)
        }

        // 1. Query MediaStore.Downloads on API 29+ (including RELATIVE_PATH for subfolders like Download/ropon)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val dlProjection = arrayOf(
                MediaStore.Downloads._ID,
                MediaStore.Downloads.DISPLAY_NAME,
                MediaStore.Downloads.SIZE,
                MediaStore.Downloads.DATE_MODIFIED,
                MediaStore.Downloads.MIME_TYPE,
                MediaStore.MediaColumns.RELATIVE_PATH
            )
            try {
                resolver.query(
                    MediaStore.Downloads.EXTERNAL_CONTENT_URI,
                    dlProjection,
                    null,
                    null,
                    "${MediaStore.Downloads.DATE_MODIFIED} DESC"
                )?.use { cursor ->
                    val idCol = cursor.getColumnIndexOrThrow(MediaStore.Downloads._ID)
                    val nameCol = cursor.getColumnIndexOrThrow(MediaStore.Downloads.DISPLAY_NAME)
                    val sizeCol = cursor.getColumnIndexOrThrow(MediaStore.Downloads.SIZE)
                    val dateCol = cursor.getColumnIndexOrThrow(MediaStore.Downloads.DATE_MODIFIED)
                    val mimeCol = cursor.getColumnIndex(MediaStore.Downloads.MIME_TYPE)
                    val relCol = cursor.getColumnIndex(MediaStore.MediaColumns.RELATIVE_PATH)

                    while (cursor.moveToNext()) {
                        val id = cursor.getLong(idCol)
                        val name = cursor.getString(nameCol) ?: continue
                        val size = cursor.getLong(sizeCol).coerceAtLeast(0L)
                        val dateSec = cursor.getLong(dateCol)
                        val mime = if (mimeCol >= 0) cursor.getString(mimeCol) else null
                        val relDir = (if (relCol >= 0) cursor.getString(relCol) else null)
                            ?.trim()?.trim('/')?.ifBlank { "Download" } ?: "Download"
                        val uri = ContentUris.withAppendedId(MediaStore.Downloads.EXTERNAL_CONTENT_URI, id)
                        val relFilePath = "$relDir/$name"
                        val key = "$relFilePath:$size"
                        if (seenKeys.add(key)) {
                            val mediaItem = DeviceMediaItem(
                                id = "dl_$id",
                                name = name,
                                uri = uri,
                                sizeBytes = size,
                                dateModifiedMillis = dateSec * 1000L,
                                mimeType = mime,
                                bucketOrFolderName = relDir,
                                relativePathInStorage = relFilePath,
                                category = FileCategory.fromFileName(name, mime)
                            )
                            allFiles.add(mediaItem)
                            recordMediaStoreFolderItem(relDir, mediaItem)
                        }
                    }
                }
            } catch (_: Exception) {
            }
        }

        // 2. Query MediaStore.Files for Documents, Archives, APKs, and files inside any subfolder
        val filesUri = MediaStore.Files.getContentUri("external")
        val fileProj = buildList {
            add(MediaStore.Files.FileColumns._ID)
            add(MediaStore.Files.FileColumns.DISPLAY_NAME)
            add(MediaStore.Files.FileColumns.SIZE)
            add(MediaStore.Files.FileColumns.DATE_MODIFIED)
            add(MediaStore.Files.FileColumns.MIME_TYPE)
            add(MediaStore.Images.Media.BUCKET_DISPLAY_NAME)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                add(MediaStore.MediaColumns.RELATIVE_PATH)
            }
            @Suppress("DEPRECATION")
            add(MediaStore.MediaColumns.DATA)
        }.toTypedArray()

        try {
            resolver.query(
                filesUri,
                fileProj,
                "${MediaStore.Files.FileColumns.SIZE} >= 0",
                null,
                "${MediaStore.Files.FileColumns.DATE_MODIFIED} DESC"
            )?.use { cursor ->
                val idCol = cursor.getColumnIndexOrThrow(MediaStore.Files.FileColumns._ID)
                val nameCol = cursor.getColumnIndex(MediaStore.Files.FileColumns.DISPLAY_NAME)
                val sizeCol = cursor.getColumnIndexOrThrow(MediaStore.Files.FileColumns.SIZE)
                val dateCol = cursor.getColumnIndexOrThrow(MediaStore.Files.FileColumns.DATE_MODIFIED)
                val mimeCol = cursor.getColumnIndex(MediaStore.Files.FileColumns.MIME_TYPE)
                val bucketCol = cursor.getColumnIndex(MediaStore.Images.Media.BUCKET_DISPLAY_NAME)
                val relCol = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    cursor.getColumnIndex(MediaStore.MediaColumns.RELATIVE_PATH)
                } else -1
                @Suppress("DEPRECATION")
                val dataCol = cursor.getColumnIndex(MediaStore.MediaColumns.DATA)

                var count = 0
                while (cursor.moveToNext() && count < 450) {
                    val id = cursor.getLong(idCol)
                    val dataPath = if (dataCol >= 0) cursor.getString(dataCol) else null
                    val name = (if (nameCol >= 0) cursor.getString(nameCol) else null)
                        ?: dataPath?.substringAfterLast('/')?.takeIf { it.isNotBlank() }
                        ?: continue
                    val size = cursor.getLong(sizeCol).coerceAtLeast(0L)
                    val dateSec = cursor.getLong(dateCol)
                    val mime = if (mimeCol >= 0) cursor.getString(mimeCol) else null
                    val bucket = if (bucketCol >= 0) cursor.getString(bucketCol) ?: "" else ""
                    val rawRel = (if (relCol >= 0) cursor.getString(relCol) else null)?.trim()?.trim('/')
                        ?: dataPath?.let { dp ->
                            if (dp.startsWith(externalRootPath)) {
                                dp.removePrefix(externalRootPath).trim('/').substringBeforeLast('/', "")
                            } else ""
                        }
                        ?: bucket
                    if (size <= 0L && dataPath != null && File(dataPath).isDirectory) continue

                    val relDir = rawRel.ifBlank { bucket.ifBlank { "التخزين" } }
                    val relFilePath = if (rawRel.isNotBlank()) "$rawRel/$name" else name
                    val key = "$relFilePath:$size"
                    if (seenKeys.add(key)) {
                        val contentUri = ContentUris.withAppendedId(filesUri, id)
                        val localF = dataPath?.let { File(it) }?.takeIf { it.exists() && it.isFile && it.canRead() }
                        val mediaItem = DeviceMediaItem(
                            id = "file_$id",
                            name = name,
                            uri = contentUri,
                            localFile = localF,
                            sizeBytes = size,
                            dateModifiedMillis = dateSec * 1000L,
                            mimeType = mime,
                            bucketOrFolderName = relDir,
                            relativePathInStorage = relFilePath,
                            category = FileCategory.fromFileName(name, mime)
                        )
                        allFiles.add(mediaItem)
                        if (rawRel.isNotBlank()) {
                            recordMediaStoreFolderItem(rawRel, mediaItem)
                        }
                        count++
                    }
                }
            }
        } catch (_: Exception) {
        }

        // 3. Scan directly accessible storage roots AND all their nested subfolders (e.g. Download/ropon)
        val rootDirs = mutableListOf<Pair<String, File>>()
        try {
            @Suppress("DEPRECATION")
            val pubDownload = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
            if (pubDownload != null) rootDirs.add("Download" to pubDownload)

            @Suppress("DEPRECATION")
            val pubDocs = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS)
            if (pubDocs != null) rootDirs.add("Documents" to pubDocs)

            @Suppress("DEPRECATION")
            val pubPics = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES)
            if (pubPics != null) rootDirs.add("Pictures" to pubPics)

            @Suppress("DEPRECATION")
            val pubDcim = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM)
            if (pubDcim != null) rootDirs.add("DCIM" to pubDcim)

            @Suppress("DEPRECATION")
            val pubMovies = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES)
            if (pubMovies != null) rootDirs.add("Movies" to pubMovies)

            @Suppress("DEPRECATION")
            val pubMusic = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MUSIC)
            if (pubMusic != null) rootDirs.add("Music" to pubMusic)

            @Suppress("DEPRECATION")
            val extRoot = Environment.getExternalStorageDirectory()
            if (extRoot != null && extRoot.exists() && extRoot.canRead()) {
                extRoot.listFiles()?.forEach { topChild ->
                    if (topChild.isDirectory && topChild.canRead() &&
                        !topChild.name.equals("Android", ignoreCase = true) &&
                        !topChild.name.startsWith(".")
                    ) {
                        rootDirs.add(topChild.name to topChild)
                    }
                }
            }
        } catch (_: Exception) {
        }

        context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS)?.let {
            rootDirs.add("Download" to it)
        }
        context.getExternalFilesDir(null)?.let {
            rootDirs.add("AppStorage" to it)
        }

        val discoveredDirs = LinkedHashMap<String, Pair<String, File>>()
        fun collectDirectoriesAndFiles(dir: File, relDisplayPath: String, depth: Int) {
            if (depth > 4 || !dir.exists() || !dir.isDirectory || !dir.canRead()) return
            val lowerPath = dir.absolutePath.lowercase(Locale.ROOT)
            if (lowerPath.contains("/android/data") || lowerPath.contains("/android/obb")) return

            discoveredDirs.putIfAbsent(dir.absolutePath, relDisplayPath to dir)
            val children = dir.listFiles() ?: return
            for (child in children) {
                if (child.name.startsWith(".")) continue
                val childRelPath = "$relDisplayPath/${child.name}"
                if (child.isDirectory && child.canRead()) {
                    collectDirectoriesAndFiles(child, childRelPath, depth + 1)
                } else if (child.isFile && child.canRead()) {
                    val len = child.length().coerceAtLeast(0L)
                    val key = "$childRelPath:$len"
                    if (seenKeys.add(key)) {
                        allFiles.add(
                            DeviceMediaItem(
                                id = "disk_${child.absolutePath.hashCode()}",
                                name = child.name,
                                localFile = child,
                                sizeBytes = len,
                                dateModifiedMillis = child.lastModified(),
                                bucketOrFolderName = relDisplayPath,
                                relativePathInStorage = childRelPath,
                                category = FileCategory.fromFileName(child.name)
                            )
                        )
                    }
                }
            }
        }

        for ((label, rootDir) in rootDirs.distinctBy { it.second.absolutePath }) {
            collectDirectoriesAndFiles(rootDir, label, 0)
        }

        val folderSummariesByRelPath = LinkedHashMap<String, StorageFolderItem>()

        for ((absPath, pair) in discoveredDirs) {
            val (relDisplay, dir) = pair
            val stats = computeRecursiveDirStats(dir, maxDepth = 20)
            val parentLabel = relDisplay.substringBeforeLast('/', "")
            val mediaFallback = mediaStoreFolderGroups[relDisplay].orEmpty()
            val mergedFileCount = max(stats.fileCount, mediaFallback.size)
            val mergedBytes = max(stats.totalBytes, mediaFallback.sumOf { it.sizeBytes })

            val folderItem = StorageFolderItem(
                name = dir.name,
                path = absPath,
                relativeDisplayPath = relDisplay,
                parentFolderName = parentLabel,
                fileCount = mergedFileCount,
                subfolderCount = stats.subfolderCount,
                emptySubfolderCount = stats.emptySubfolderCount,
                totalBytes = mergedBytes,
                lastModifiedMillis = dir.lastModified(),
                mediaStoreFallbackItems = mediaFallback
            )
            folderSummariesByRelPath[relDisplay] = folderItem
        }

        // Also include any MediaStore-discovered folders (like "Download/ropon") not already in discoveredDirs
        for ((relDisplay, itemsInGroup) in mediaStoreFolderGroups) {
            if (relDisplay !in folderSummariesByRelPath && itemsInGroup.isNotEmpty()) {
                val folderName = relDisplay.substringAfterLast('/')
                val parentLabel = relDisplay.substringBeforeLast('/', "")
                val candidateFile = File(externalRootPath, relDisplay)
                val nestedSubdirs = itemsInGroup.mapNotNull { item ->
                    val afterPrefix = item.relativePathInStorage.removePrefix("$relDisplay/")
                    afterPrefix.substringBeforeLast('/', "").takeIf { it.isNotBlank() }
                }.distinct().size

                folderSummariesByRelPath[relDisplay] = StorageFolderItem(
                    name = folderName,
                    path = candidateFile.absolutePath,
                    relativeDisplayPath = relDisplay,
                    parentFolderName = parentLabel,
                    fileCount = itemsInGroup.size,
                    subfolderCount = nestedSubdirs,
                    emptySubfolderCount = 0,
                    totalBytes = itemsInGroup.sumOf { it.sizeBytes },
                    lastModifiedMillis = itemsInGroup.maxOfOrNull { it.dateModifiedMillis } ?: System.currentTimeMillis(),
                    mediaStoreFallbackItems = itemsInGroup
                )
            }
        }

        // Sort folders so user subfolders inside Download/Documents (like Download/ropon) appear prominently at the top
        val sortedFolders = folderSummariesByRelPath.values.sortedWith(
            compareByDescending<StorageFolderItem> {
                it.relativeDisplayPath.startsWith("Download/", ignoreCase = true) &&
                    !it.name.equals("BarqSher", ignoreCase = true)
            }
                .thenByDescending { it.relativeDisplayPath.contains('/') }
                .thenByDescending { it.fileCount > 0 || it.subfolderCount > 0 }
                .thenByDescending { it.lastModifiedMillis }
        )

        return allFiles to sortedFolders
    }

    private fun computeRecursiveDirStats(dir: File, maxDepth: Int = 20): RecursiveDirStats {
        if (maxDepth <= 0 || !dir.exists() || !dir.isDirectory || !dir.canRead()) {
            return RecursiveDirStats(0, 0, 0, 0L)
        }
        val list = dir.listFiles() ?: return RecursiveDirStats(0, 0, 0, 0L)
        var filesCount = 0
        var subfoldersCount = 0
        var emptySubfoldersCount = 0
        var bytesCount = 0L

        for (f in list) {
            if (f.name.startsWith(".")) continue
            if (f.isDirectory && f.canRead()) {
                subfoldersCount++
                val sub = computeRecursiveDirStats(f, maxDepth - 1)
                filesCount += sub.fileCount
                subfoldersCount += sub.subfolderCount
                emptySubfoldersCount += sub.emptySubfolderCount
                bytesCount += sub.totalBytes
                if (sub.fileCount == 0 && sub.subfolderCount == 0) {
                    emptySubfoldersCount++
                }
            } else if (f.isFile && f.canRead()) {
                filesCount++
                bytesCount += f.length().coerceAtLeast(0L)
            }
        }
        return RecursiveDirStats(filesCount, subfoldersCount, emptySubfoldersCount, bytesCount)
    }

    data class FolderScanResult(
        val batchInfo: FolderBatchInfo?,
        val transferItems: List<TransferFileItem>,
        val previewMediaItems: List<DeviceMediaItem>,
        val errorMessage: String? = null
    )

    /**
     * Scans a selected StorageFolderItem (such as "Download/ropon") into a single unified FolderBatchInfo
     * and recursive list of TransferFileItems (preserving root folder name, relative paths, subfolders,
     * and empty directories), seamlessly merging local filesystem scan with MediaStore items if needed.
     */
    fun scanStorageFolderItemForTransfer(
        folderItem: StorageFolderItem,
        chunkSizeBytes: Int,
        context: Context? = null
    ): FolderScanResult {
        if (folderItem.isProtectedSystemFolder) {
            return FolderScanResult(
                batchInfo = null,
                transferItems = emptyList(),
                previewMediaItems = emptyList(),
                errorMessage = folderItem.protectionReason
                    ?: "هذا المجلد (${folderItem.relativeDisplayPath}) محمي بسياسة نظام Android 11+ (Android/data أو Android/obb) ولا يسمح النظام بالوصول إليه."
            )
        }
        if (folderItem.safTreeUri != null && context != null) {
            return scanDocumentTreeForTransfer(
                context = context,
                treeUri = folderItem.safTreeUri,
                chunkSizeBytes = chunkSizeBytes,
                startDocId = folderItem.safDocumentId,
                customRootName = folderItem.name
            )
        }
        val rootDir = File(folderItem.path)
        val localResult = if (rootDir.exists() && rootDir.isDirectory && rootDir.canRead()) {
            scanLocalFolderForTransfer(rootDir, chunkSizeBytes)
        } else {
            null
        }

        val rootFolderName = sanitizePathSegment(folderItem.name.ifBlank { "Folder" })
        val batchId = localResult?.batchInfo?.batchId ?: "fld_${UUID.randomUUID().toString().take(8)}"
        val mergedTransferItems = mutableListOf<TransferFileItem>()
        val mergedPreviewItems = mutableListOf<DeviceMediaItem>()
        val seenRelPaths = HashSet<String>()

        if (localResult != null && localResult.errorMessage == null) {
            for (item in localResult.transferItems) {
                // Keep real files or empty subdirectories; if root itself was marked empty but we have MediaStore items, we'll replace it
                if (item.id.endsWith("_root_empty") && folderItem.mediaStoreFallbackItems.isNotEmpty()) continue
                mergedTransferItems.add(item)
                seenRelPaths.add(item.relativePath.lowercase(Locale.ROOT))
            }
            mergedPreviewItems.addAll(localResult.previewMediaItems)
        }

        // Merge any MediaStore-indexed files inside this folder that weren't returned by File.listFiles()
        val prefixToRemove = folderItem.relativeDisplayPath.trim('/').let { "$it/" }
        for (media in folderItem.mediaStoreFallbackItems) {
            val innerRel = if (media.relativePathInStorage.startsWith(prefixToRemove, ignoreCase = true)) {
                media.relativePathInStorage.substring(prefixToRemove.length)
            } else {
                media.name
            }
            val cleanSegments = innerRel.replace('\\', '/').split('/')
                .map { sanitizePathSegment(it) }
                .filter { it.isNotBlank() }
            val fullRelPath = if (cleanSegments.isEmpty()) {
                "$rootFolderName/${sanitizePathSegment(media.name)}"
            } else {
                "$rootFolderName/${cleanSegments.joinToString("/")}"
            }

            if (seenRelPaths.add(fullRelPath.lowercase(Locale.ROOT))) {
                val size = media.sizeBytes.coerceAtLeast(0L)
                val chunks = max(1, ((size + chunkSizeBytes - 1) / chunkSizeBytes).toInt())
                mergedTransferItems.add(
                    TransferFileItem(
                        id = "${batchId}_ms_${mergedTransferItems.size}",
                        name = cleanSegments.lastOrNull() ?: sanitizePathSegment(media.name),
                        sizeBytes = size,
                        category = media.category,
                        uri = media.uri,
                        localFile = media.localFile,
                        relativePath = fullRelPath,
                        rootFolderName = rootFolderName,
                        folderBatchId = batchId,
                        isDirectory = false,
                        totalChunks = chunks,
                        sha256Expected = if (size == 0L) Sha256Util.EMPTY_BYTES_SHA256 else ""
                    )
                )
                mergedPreviewItems.add(media)
            }
        }

        if (mergedTransferItems.isEmpty()) {
            if (!rootDir.exists() && folderItem.mediaStoreFallbackItems.isEmpty()) {
                return FolderScanResult(
                    batchInfo = null,
                    transferItems = emptyList(),
                    previewMediaItems = emptyList(),
                    errorMessage = "المجلد المحدد (${folderItem.relativeDisplayPath}) غير موجود أو لا يمكن الوصول إليه"
                )
            }
            // Empty root folder: still transfer it as an empty directory unit so receiver creates it
            mergedTransferItems.add(
                TransferFileItem(
                    id = "${batchId}_root_empty",
                    name = rootFolderName,
                    sizeBytes = 0L,
                    category = FileCategory.FOLDER,
                    localFile = rootDir.takeIf { it.exists() },
                    relativePath = rootFolderName,
                    rootFolderName = rootFolderName,
                    folderBatchId = batchId,
                    isDirectory = true,
                    totalChunks = 1,
                    sha256Expected = Sha256Util.EMPTY_DIR_SHA256
                )
            )
        }

        val totalFiles = mergedTransferItems.count { !it.isDirectory }
        val emptyDirs = mergedTransferItems.count { it.isDirectory }
        val totalSubfolders = max(
            localResult?.batchInfo?.totalSubfoldersCount ?: folderItem.subfolderCount,
            emptyDirs
        )
        val totalBytes = mergedTransferItems.filter { !it.isDirectory }.sumOf { it.sizeBytes }

        val batchInfo = FolderBatchInfo(
            batchId = batchId,
            rootFolderName = rootFolderName,
            sourceUriOrPath = folderItem.relativeDisplayPath.ifBlank { folderItem.path },
            totalFilesCount = totalFiles,
            totalSubfoldersCount = totalSubfolders,
            emptyFoldersCount = emptyDirs,
            totalBytes = totalBytes,
            skippedUnreadableCount = localResult?.batchInfo?.skippedUnreadableCount ?: 0,
            hasPersistentPermission = true
        )

        return FolderScanResult(
            batchInfo = batchInfo,
            transferItems = mergedTransferItems,
            previewMediaItems = mergedPreviewItems,
            errorMessage = null
        )
    }

    /**
     * Recursively reads an entire user-selected folder from ACTION_OPEN_DOCUMENT_TREE,
     * persisting read permissions and building a unified transfer manifest that preserves
     * all nested subdirectories, relative paths, empty folders, and 0-byte files.
     */
    fun scanDocumentTreeForTransfer(
        context: Context,
        treeUri: Uri,
        chunkSizeBytes: Int,
        startDocId: String? = null,
        customRootName: String? = null
    ): FolderScanResult {
        val resolver = context.contentResolver
        var hasPersistentPerm = false
        try {
            resolver.takePersistableUriPermission(
                treeUri,
                Intent.FLAG_GRANT_READ_URI_PERMISSION
            )
            hasPersistentPerm = true
        } catch (_: SecurityException) {
            // Provider may only grant transient session read permission
        } catch (_: Exception) {
        }

        val rootDocId = startDocId ?: try {
            DocumentsContract.getTreeDocumentId(treeUri)
        } catch (e: Exception) {
            return FolderScanResult(
                batchInfo = null,
                transferItems = emptyList(),
                previewMediaItems = emptyList(),
                errorMessage = "تعذر قراءة معرّف المجلد المختار: ${e.localizedMessage ?: "URI غير صالح"}"
            )
        }

        val lowerDocId = rootDocId.lowercase(Locale.ROOT)
        if (lowerDocId.contains("android/data") || lowerDocId.contains("android/obb")) {
            return FolderScanResult(
                batchInfo = null,
                transferItems = emptyList(),
                previewMediaItems = emptyList(),
                errorMessage = "هذا المجلد (${rootDocId}) محمي من نظام Android 11+ (Android/data أو Android/obb) ولا يسمح النظام بالوصول إليه بدون صلاحيات خاصة."
            )
        }

        val rootFolderName = sanitizePathSegment(
            customRootName?.takeIf { it.isNotBlank() } ?: resolveTreeRootFolderName(resolver, treeUri, rootDocId)
        )
        val batchId = "fld_${UUID.randomUUID().toString().take(8)}"
        val transferItems = mutableListOf<TransferFileItem>()
        val previewItems = mutableListOf<DeviceMediaItem>()
        var totalFilesCount = 0
        var totalSubfoldersCount = 0
        var emptyFoldersCount = 0
        var totalBytes = 0L
        var skippedUnreadableCount = 0

        val projection = arrayOf(
            DocumentsContract.Document.COLUMN_DOCUMENT_ID,
            DocumentsContract.Document.COLUMN_DISPLAY_NAME,
            DocumentsContract.Document.COLUMN_SIZE,
            DocumentsContract.Document.COLUMN_LAST_MODIFIED,
            DocumentsContract.Document.COLUMN_MIME_TYPE
        )

        fun traverseDir(currentDocId: String, currentRelPath: String, depth: Int): Int {
            if (depth > 24) return 0
            val childrenUri = try {
                DocumentsContract.buildChildDocumentsUriUsingTree(treeUri, currentDocId)
            } catch (_: Exception) {
                skippedUnreadableCount++
                return 0
            }

            var entriesInThisDir = 0
            val usedSiblingNames = HashSet<String>()

            try {
                val cursor = resolver.query(childrenUri, projection, null, null, null)
                if (cursor == null) {
                    skippedUnreadableCount++
                    return 0
                }
                cursor.use { c ->
                    val idCol = c.getColumnIndexOrThrow(DocumentsContract.Document.COLUMN_DOCUMENT_ID)
                    val nameCol = c.getColumnIndexOrThrow(DocumentsContract.Document.COLUMN_DISPLAY_NAME)
                    val sizeCol = c.getColumnIndexOrThrow(DocumentsContract.Document.COLUMN_SIZE)
                    val dateCol = c.getColumnIndex(DocumentsContract.Document.COLUMN_LAST_MODIFIED)
                    val mimeCol = c.getColumnIndex(DocumentsContract.Document.COLUMN_MIME_TYPE)

                    while (c.moveToNext()) {
                        val childDocId = c.getString(idCol) ?: continue
                        val rawName = c.getString(nameCol) ?: "عنصر_${entriesInThisDir + 1}"
                        val safeName = deduplicateSiblingName(sanitizePathSegment(rawName), usedSiblingNames)
                        val mime = if (mimeCol >= 0) c.getString(mimeCol) else null
                        val lastMod = if (dateCol >= 0 && !c.isNull(dateCol)) c.getLong(dateCol) else System.currentTimeMillis()
                        val childRelPath = "$currentRelPath/$safeName"
                        entriesInThisDir++

                        if (mime == DocumentsContract.Document.MIME_TYPE_DIR) {
                            totalSubfoldersCount++
                            val subEntries = traverseDir(childDocId, childRelPath, depth + 1)
                            if (subEntries == 0) {
                                // Empty subfolder: add explicit directory item so receiver recreates it
                                emptyFoldersCount++
                                transferItems.add(
                                    TransferFileItem(
                                        id = "${batchId}_dir_${transferItems.size}",
                                        name = safeName,
                                        sizeBytes = 0L,
                                        category = FileCategory.FOLDER,
                                        relativePath = childRelPath,
                                        rootFolderName = rootFolderName,
                                        folderBatchId = batchId,
                                        isDirectory = true,
                                        totalChunks = 1,
                                        sha256Expected = Sha256Util.EMPTY_DIR_SHA256
                                    )
                                )
                            }
                        } else {
                            var size = if (!c.isNull(sizeCol)) c.getLong(sizeCol).coerceAtLeast(0L) else 0L
                            val childUri = DocumentsContract.buildDocumentUriUsingTree(treeUri, childDocId)
                            if (size == 0L) {
                                try {
                                    resolver.openAssetFileDescriptor(childUri, "r")?.use { afd ->
                                        if (afd.length > 0) size = afd.length
                                    }
                                } catch (_: Exception) {
                                }
                            }
                            val chunks = max(1, ((size + chunkSizeBytes - 1) / chunkSizeBytes).toInt())
                            val cat = FileCategory.fromFileName(safeName, mime)
                            totalFilesCount++
                            totalBytes += size

                            transferItems.add(
                                TransferFileItem(
                                    id = "${batchId}_f_${transferItems.size}",
                                    name = safeName,
                                    sizeBytes = size,
                                    category = cat,
                                    uri = childUri,
                                    relativePath = childRelPath,
                                    rootFolderName = rootFolderName,
                                    folderBatchId = batchId,
                                    isDirectory = false,
                                    totalChunks = chunks,
                                    sha256Expected = if (size == 0L) Sha256Util.EMPTY_BYTES_SHA256 else ""
                                )
                            )
                            previewItems.add(
                                DeviceMediaItem(
                                    id = "saf_${childUri.hashCode()}_${previewItems.size}",
                                    name = childRelPath,
                                    uri = childUri,
                                    sizeBytes = size,
                                    dateModifiedMillis = lastMod,
                                    mimeType = mime,
                                    bucketOrFolderName = rootFolderName,
                                    category = cat
                                )
                            )
                        }
                    }
                }
            } catch (_: SecurityException) {
                skippedUnreadableCount++
            } catch (_: Exception) {
                skippedUnreadableCount++
            }
            return entriesInThisDir
        }

        val rootEntries = traverseDir(rootDocId, rootFolderName, 0)
        if (rootEntries == 0 && skippedUnreadableCount > 0 && transferItems.isEmpty()) {
            return FolderScanResult(
                batchInfo = null,
                transferItems = emptyList(),
                previewMediaItems = emptyList(),
                errorMessage = "تعذر قراءة محتويات المجلد ($rootFolderName) لأن نظام Android يقيد الوصول إليه."
            )
        }

        // If the selected root folder itself is completely empty, still transfer it as an empty directory
        if (transferItems.isEmpty()) {
            emptyFoldersCount = 1
            transferItems.add(
                TransferFileItem(
                    id = "${batchId}_root_empty",
                    name = rootFolderName,
                    sizeBytes = 0L,
                    category = FileCategory.FOLDER,
                    relativePath = rootFolderName,
                    rootFolderName = rootFolderName,
                    folderBatchId = batchId,
                    isDirectory = true,
                    totalChunks = 1,
                    sha256Expected = Sha256Util.EMPTY_DIR_SHA256
                )
            )
        }

        val batchInfo = FolderBatchInfo(
            batchId = batchId,
            rootFolderName = rootFolderName,
            sourceUriOrPath = treeUri.toString(),
            totalFilesCount = totalFilesCount,
            totalSubfoldersCount = totalSubfoldersCount,
            emptyFoldersCount = emptyFoldersCount,
            totalBytes = totalBytes,
            skippedUnreadableCount = skippedUnreadableCount,
            hasPersistentPermission = hasPersistentPerm
        )

        return FolderScanResult(
            batchInfo = batchInfo,
            transferItems = transferItems,
            previewMediaItems = previewItems,
            errorMessage = null
        )
    }

    /**
     * Recursively scans a local java.io.File directory to send the entire folder as one unit,
     * preserving nested subfolders, relative paths, empty directories, and 0-byte files.
     */
    fun scanLocalFolderForTransfer(
        rootDir: File,
        chunkSizeBytes: Int
    ): FolderScanResult {
        if (!rootDir.exists() || !rootDir.isDirectory) {
            return FolderScanResult(
                batchInfo = null,
                transferItems = emptyList(),
                previewMediaItems = emptyList(),
                errorMessage = "المجلد المحدد غير موجود على الجهاز"
            )
        }
        if (!rootDir.canRead()) {
            return FolderScanResult(
                batchInfo = null,
                transferItems = emptyList(),
                previewMediaItems = emptyList(),
                errorMessage = "هذا المجلد (${rootDir.name}) محمي من نظام Android ولا يمكن قراءته بدون إذن خاص"
            )
        }

        val rootFolderName = sanitizePathSegment(rootDir.name.ifBlank { "Folder" })
        val batchId = "fld_${UUID.randomUUID().toString().take(8)}"
        val transferItems = mutableListOf<TransferFileItem>()
        val previewItems = mutableListOf<DeviceMediaItem>()
        var totalFilesCount = 0
        var totalSubfoldersCount = 0
        var emptyFoldersCount = 0
        var totalBytes = 0L
        var skippedUnreadableCount = 0

        fun traverseLocal(currentDir: File, currentRelPath: String, depth: Int): Int {
            if (depth > 24) return 0
            if (!currentDir.canRead()) {
                skippedUnreadableCount++
                return 0
            }
            val children = currentDir.listFiles()
            if (children == null) {
                skippedUnreadableCount++
                return 0
            }

            val sortedChildren = children.sortedWith(compareBy<File>({ !it.isDirectory }, { it.name.lowercase(Locale.ROOT) }))
            val usedSiblingNames = HashSet<String>()
            var entriesInThisDir = 0

            for (child in sortedChildren) {
                val safeName = deduplicateSiblingName(sanitizePathSegment(child.name), usedSiblingNames)
                val childRelPath = "$currentRelPath/$safeName"
                entriesInThisDir++

                if (child.isDirectory) {
                    totalSubfoldersCount++
                    val subCount = traverseLocal(child, childRelPath, depth + 1)
                    if (subCount == 0) {
                        emptyFoldersCount++
                        transferItems.add(
                            TransferFileItem(
                                id = "${batchId}_dir_${transferItems.size}",
                                name = safeName,
                                sizeBytes = 0L,
                                category = FileCategory.FOLDER,
                                localFile = child,
                                relativePath = childRelPath,
                                rootFolderName = rootFolderName,
                                folderBatchId = batchId,
                                isDirectory = true,
                                totalChunks = 1,
                                sha256Expected = Sha256Util.EMPTY_DIR_SHA256
                            )
                        )
                    }
                } else if (child.isFile) {
                    if (!child.canRead()) {
                        skippedUnreadableCount++
                        continue
                    }
                    val size = child.length().coerceAtLeast(0L)
                    val chunks = max(1, ((size + chunkSizeBytes - 1) / chunkSizeBytes).toInt())
                    val cat = FileCategory.fromFileName(safeName)
                    totalFilesCount++
                    totalBytes += size

                    transferItems.add(
                        TransferFileItem(
                            id = "${batchId}_f_${transferItems.size}",
                            name = safeName,
                            sizeBytes = size,
                            category = cat,
                            localFile = child,
                            relativePath = childRelPath,
                            rootFolderName = rootFolderName,
                            folderBatchId = batchId,
                            isDirectory = false,
                            totalChunks = chunks,
                            sha256Expected = if (size == 0L) Sha256Util.EMPTY_BYTES_SHA256 else ""
                        )
                    )
                    previewItems.add(
                        DeviceMediaItem(
                            id = "local_${child.absolutePath.hashCode()}",
                            name = childRelPath,
                            localFile = child,
                            sizeBytes = size,
                            dateModifiedMillis = child.lastModified(),
                            bucketOrFolderName = rootFolderName,
                            category = cat
                        )
                    )
                }
            }
            return entriesInThisDir
        }

        traverseLocal(rootDir, rootFolderName, 0)

        if (transferItems.isEmpty()) {
            emptyFoldersCount = 1
            transferItems.add(
                TransferFileItem(
                    id = "${batchId}_root_empty",
                    name = rootFolderName,
                    sizeBytes = 0L,
                    category = FileCategory.FOLDER,
                    localFile = rootDir,
                    relativePath = rootFolderName,
                    rootFolderName = rootFolderName,
                    folderBatchId = batchId,
                    isDirectory = true,
                    totalChunks = 1,
                    sha256Expected = Sha256Util.EMPTY_DIR_SHA256
                )
            )
        }

        val batchInfo = FolderBatchInfo(
            batchId = batchId,
            rootFolderName = rootFolderName,
            sourceUriOrPath = rootDir.absolutePath,
            totalFilesCount = totalFilesCount,
            totalSubfoldersCount = totalSubfoldersCount,
            emptyFoldersCount = emptyFoldersCount,
            totalBytes = totalBytes,
            skippedUnreadableCount = skippedUnreadableCount,
            hasPersistentPermission = true
        )

        return FolderScanResult(
            batchInfo = batchInfo,
            transferItems = transferItems,
            previewMediaItems = previewItems,
            errorMessage = null
        )
    }

    private fun resolveTreeRootFolderName(
        resolver: ContentResolver,
        treeUri: Uri,
        rootDocId: String
    ): String {
        try {
            val docUri = DocumentsContract.buildDocumentUriUsingTree(treeUri, rootDocId)
            resolver.query(
                docUri,
                arrayOf(DocumentsContract.Document.COLUMN_DISPLAY_NAME),
                null,
                null,
                null
            )?.use { c ->
                if (c.moveToFirst()) {
                    val name = c.getString(0)
                    if (!name.isNullOrBlank()) return name
                }
            }
        } catch (_: Exception) {
        }
        val decoded = try {
            URLDecoder.decode(rootDocId, "UTF-8")
        } catch (_: Exception) {
            rootDocId
        }
        return decoded.substringAfterLast(':').substringAfterLast('/').ifBlank { "مجلد_مرسل" }
    }

    fun sanitizePathSegment(raw: String): String {
        val cleaned = raw.trim()
            .replace('\\', '_')
            .replace('/', '_')
            .replace(":", "_")
            .replace("*", "_")
            .replace("?", "_")
            .replace("\"", "_")
            .replace("<", "_")
            .replace(">", "_")
            .replace("|", "_")
        return if (cleaned.isBlank() || cleaned == "." || cleaned == "..") "مجلد" else cleaned
    }

    fun deduplicateSiblingName(baseName: String, usedNamesLower: MutableSet<String>): String {
        val lower = baseName.lowercase(Locale.ROOT)
        if (usedNamesLower.add(lower)) return baseName
        val dotIdx = baseName.lastIndexOf('.')
        val stem = if (dotIdx > 0) baseName.substring(0, dotIdx) else baseName
        val ext = if (dotIdx > 0) baseName.substring(dotIdx) else ""
        var counter = 1
        while (true) {
            val candidate = "$stem ($counter)$ext"
            if (usedNamesLower.add(candidate.lowercase(Locale.ROOT))) {
                return candidate
            }
            counter++
        }
    }

    /**
     * Reads files inside a user-picked SAF folder (OpenDocumentTree) for previewing in Files tab.
     */
    fun loadFilesFromDocumentTree(context: Context, treeUri: Uri): List<DeviceMediaItem> {
        return scanDocumentTreeForTransfer(context, treeUri, 1024 * 1024).previewMediaItems
    }

    /**
     * Returns all persisted SAF directory trees granted by the user via ACTION_OPEN_DOCUMENT_TREE.
     */
    fun loadPersistedSafFolders(context: Context): List<PersistedSafFolderItem> {
        val resolver = context.contentResolver
        val result = mutableListOf<PersistedSafFolderItem>()
        try {
            val perms = resolver.persistedUriPermissions
            for (perm in perms) {
                if (!perm.isReadPermission) continue
                val uri = perm.uri
                val docId = try {
                    DocumentsContract.getTreeDocumentId(uri)
                } catch (_: Exception) {
                    continue
                }
                val name = resolveTreeRootFolderName(resolver, uri, docId)
                result.add(
                    PersistedSafFolderItem(
                        uri = uri,
                        displayName = name,
                        documentId = docId
                    )
                )
            }
        } catch (_: Exception) {
        }
        return result
    }

    /**
     * Lists the immediate child folders and files inside a granted SAF tree URI (at root or any nested documentId),
     * enabling full hierarchical folder navigation and selection inside SAF directories.
     */
    fun browseSafDirectoryChildren(
        context: Context,
        treeUri: Uri,
        parentDocId: String?,
        parentDisplayPath: String
    ): Pair<List<StorageFolderItem>, List<DeviceMediaItem>> {
        val resolver = context.contentResolver
        val docId = parentDocId ?: try {
            DocumentsContract.getTreeDocumentId(treeUri)
        } catch (_: Exception) {
            return emptyList<StorageFolderItem>() to emptyList()
        }

        val childFolders = mutableListOf<StorageFolderItem>()
        val childFiles = mutableListOf<DeviceMediaItem>()
        val projection = arrayOf(
            DocumentsContract.Document.COLUMN_DOCUMENT_ID,
            DocumentsContract.Document.COLUMN_DISPLAY_NAME,
            DocumentsContract.Document.COLUMN_SIZE,
            DocumentsContract.Document.COLUMN_LAST_MODIFIED,
            DocumentsContract.Document.COLUMN_MIME_TYPE
        )

        try {
            val childrenUri = DocumentsContract.buildChildDocumentsUriUsingTree(treeUri, docId)
            resolver.query(childrenUri, projection, null, null, null)?.use { c ->
                val idCol = c.getColumnIndexOrThrow(DocumentsContract.Document.COLUMN_DOCUMENT_ID)
                val nameCol = c.getColumnIndexOrThrow(DocumentsContract.Document.COLUMN_DISPLAY_NAME)
                val sizeCol = c.getColumnIndexOrThrow(DocumentsContract.Document.COLUMN_SIZE)
                val dateCol = c.getColumnIndex(DocumentsContract.Document.COLUMN_LAST_MODIFIED)
                val mimeCol = c.getColumnIndex(DocumentsContract.Document.COLUMN_MIME_TYPE)

                while (c.moveToNext()) {
                    val childDocId = c.getString(idCol) ?: continue
                    val rawName = c.getString(nameCol) ?: "عنصر"
                    val mime = if (mimeCol >= 0) c.getString(mimeCol) else null
                    val lastMod = if (dateCol >= 0 && !c.isNull(dateCol)) c.getLong(dateCol) else System.currentTimeMillis()
                    val cleanParent = parentDisplayPath.trim('/')
                    val childRelPath = if (cleanParent.isEmpty()) rawName else "$cleanParent/$rawName"

                    if (mime == DocumentsContract.Document.MIME_TYPE_DIR) {
                        // Compute quick child count for this SAF subfolder
                        var subFiles = 0
                        var subFolders = 0
                        var subBytes = 0L
                        try {
                            val subUri = DocumentsContract.buildChildDocumentsUriUsingTree(treeUri, childDocId)
                            resolver.query(subUri, projection, null, null, null)?.use { sc ->
                                val sSizeCol = sc.getColumnIndexOrThrow(DocumentsContract.Document.COLUMN_SIZE)
                                val sMimeCol = sc.getColumnIndex(DocumentsContract.Document.COLUMN_MIME_TYPE)
                                while (sc.moveToNext()) {
                                    val sm = if (sMimeCol >= 0) sc.getString(sMimeCol) else null
                                    if (sm == DocumentsContract.Document.MIME_TYPE_DIR) {
                                        subFolders++
                                    } else {
                                        subFiles++
                                        if (!sc.isNull(sSizeCol)) {
                                            subBytes += sc.getLong(sSizeCol).coerceAtLeast(0L)
                                        }
                                    }
                                }
                            }
                        } catch (_: Exception) {
                        }
                        childFolders.add(
                            StorageFolderItem(
                                name = rawName,
                                path = "saf://$treeUri#$childDocId",
                                relativeDisplayPath = childRelPath,
                                parentFolderName = cleanParent,
                                fileCount = subFiles,
                                subfolderCount = subFolders,
                                emptySubfolderCount = if (subFiles == 0 && subFolders == 0) 1 else 0,
                                totalBytes = subBytes,
                                lastModifiedMillis = lastMod,
                                safTreeUri = treeUri,
                                safDocumentId = childDocId
                            )
                        )
                    } else {
                        val size = if (!c.isNull(sizeCol)) c.getLong(sizeCol).coerceAtLeast(0L) else 0L
                        val childUri = DocumentsContract.buildDocumentUriUsingTree(treeUri, childDocId)
                        childFiles.add(
                            DeviceMediaItem(
                                id = "saf_nav_${childUri.hashCode()}",
                                name = rawName,
                                uri = childUri,
                                sizeBytes = size,
                                dateModifiedMillis = lastMod,
                                mimeType = mime,
                                bucketOrFolderName = cleanParent,
                                relativePathInStorage = childRelPath,
                                category = FileCategory.fromFileName(rawName, mime)
                            )
                        )
                    }
                }
            }
        } catch (_: Exception) {
        }
        return childFolders to childFiles
    }

    /**
     * Lists the immediate child folders and immediate child files inside a specific relative or absolute
     * local folder path (e.g. "Download", "Download/ropon", "Download/ropon/levels"), merging actual
     * filesystem contents with MediaStore-indexed items for true hierarchical directory navigation.
     */
    fun browseLocalDirectoryChildren(
        browsingRelOrAbsPath: String,
        allKnownFolders: List<StorageFolderItem>,
        allKnownFiles: List<DeviceMediaItem>
    ): Pair<List<StorageFolderItem>, List<DeviceMediaItem>> {
        @Suppress("DEPRECATION")
        val extRoot = try {
            Environment.getExternalStorageDirectory()
        } catch (_: Exception) {
            null
        }
        val cleanRel = browsingRelOrAbsPath.trim().trim('/').replace('\\', '/')
        val matchingFolder = allKnownFolders.firstOrNull {
            it.relativeDisplayPath.equals(cleanRel, ignoreCase = true) ||
                it.path.equals(browsingRelOrAbsPath.trim(), ignoreCase = true)
        }
        val targetDir: File? = when {
            matchingFolder != null -> File(matchingFolder.path)
            File(browsingRelOrAbsPath).isAbsolute -> File(browsingRelOrAbsPath)
            extRoot != null -> File(extRoot, cleanRel)
            else -> null
        }
        val displayPrefix = matchingFolder?.relativeDisplayPath?.trim('/') ?: cleanRel

        val immediateSubfolders = LinkedHashMap<String, StorageFolderItem>()
        val immediateFiles = LinkedHashMap<String, DeviceMediaItem>()

        // 1. Inspect direct filesystem children if directory is readable
        if (targetDir != null && targetDir.exists() && targetDir.isDirectory && targetDir.canRead()) {
            val diskChildren = targetDir.listFiles().orEmpty()
                .filterNot { it.name.startsWith(".") }
                .sortedWith(compareBy<File>({ !it.isDirectory }, { it.name.lowercase(Locale.ROOT) }))

            for (child in diskChildren) {
                val childRel = if (displayPrefix.isBlank()) child.name else "$displayPrefix/${child.name}"
                if (child.isDirectory) {
                    val lower = child.absolutePath.lowercase(Locale.ROOT)
                    val isProtected = (lower.endsWith("/android/data") || lower.endsWith("/android/obb") ||
                        lower.contains("/android/data/") || lower.contains("/android/obb/")) && !child.canRead()
                    val existingSummary = allKnownFolders.firstOrNull {
                        it.path == child.absolutePath || it.relativeDisplayPath.equals(childRel, ignoreCase = true)
                    }
                    if (existingSummary != null) {
                        immediateSubfolders[childRel.lowercase(Locale.ROOT)] = existingSummary
                    } else {
                        val stats = computeRecursiveDirStats(child, maxDepth = 12)
                        immediateSubfolders[childRel.lowercase(Locale.ROOT)] = StorageFolderItem(
                            name = child.name,
                            path = child.absolutePath,
                            relativeDisplayPath = childRel,
                            parentFolderName = displayPrefix,
                            fileCount = stats.fileCount,
                            subfolderCount = stats.subfolderCount,
                            emptySubfolderCount = stats.emptySubfolderCount,
                            totalBytes = stats.totalBytes,
                            lastModifiedMillis = child.lastModified(),
                            isProtectedSystemFolder = isProtected,
                            protectionReason = if (isProtected) {
                                "مجلد نظام محمي في Android 11+ (${childRel})؛ يمنع النظام الوصول المباشر إليه."
                            } else null
                        )
                    }
                } else if (child.isFile && child.canRead()) {
                    val existingFile = allKnownFiles.firstOrNull {
                        it.localFile?.absolutePath == child.absolutePath ||
                            it.relativePathInStorage.equals(childRel, ignoreCase = true)
                    }
                    val mediaItem = existingFile ?: DeviceMediaItem(
                        id = "disk_${child.absolutePath.hashCode()}",
                        name = child.name,
                        localFile = child,
                        sizeBytes = child.length().coerceAtLeast(0L),
                        dateModifiedMillis = child.lastModified(),
                        bucketOrFolderName = displayPrefix,
                        relativePathInStorage = childRel,
                        category = FileCategory.fromFileName(child.name)
                    )
                    immediateFiles[child.name.lowercase(Locale.ROOT)] = mediaItem
                }
            }
        }

        // 2. Merge immediate subfolders and immediate files from MediaStore / allKnownFolders
        val prefixSlash = "$displayPrefix/"
        for (folder in allKnownFolders) {
            val rel = folder.relativeDisplayPath.trim('/')
            if (rel.startsWith(prefixSlash, ignoreCase = true)) {
                val remainder = rel.substring(prefixSlash.length)
                if (remainder.isNotBlank() && !remainder.contains('/')) {
                    immediateSubfolders.putIfAbsent(rel.lowercase(Locale.ROOT), folder)
                }
            }
        }
        for (file in allKnownFiles) {
            val relFile = file.relativePathInStorage.trim('/')
            if (file.bucketOrFolderName.equals(displayPrefix, ignoreCase = true)) {
                immediateFiles.putIfAbsent(file.name.lowercase(Locale.ROOT), file)
            } else if (relFile.startsWith(prefixSlash, ignoreCase = true)) {
                val remainder = relFile.substring(prefixSlash.length)
                if (remainder.isNotBlank() && !remainder.contains('/')) {
                    immediateFiles.putIfAbsent(file.name.lowercase(Locale.ROOT), file)
                }
            }
        }

        return immediateSubfolders.values.toList() to immediateFiles.values.toList()
    }

    private fun loadMediaThumbnail(
        resolver: ContentResolver,
        uri: Uri,
        mediaId: Long,
        isVideo: Boolean
    ): ImageBitmap? {
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                resolver.loadThumbnail(uri, Size(96, 96), null).asImageBitmap()
            } else {
                val opts = BitmapFactory.Options().apply {
                    inSampleSize = 4
                }
                @Suppress("DEPRECATION")
                val bmp = if (isVideo) {
                    MediaStore.Video.Thumbnails.getThumbnail(
                        resolver,
                        mediaId,
                        MediaStore.Video.Thumbnails.MINI_KIND,
                        opts
                    )
                } else {
                    MediaStore.Images.Thumbnails.getThumbnail(
                        resolver,
                        mediaId,
                        MediaStore.Images.Thumbnails.MINI_KIND,
                        opts
                    )
                }
                bmp?.asImageBitmap()
            }
        } catch (_: Throwable) {
            null
        }
    }
}
